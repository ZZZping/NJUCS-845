#include <iostream>
using namespace std;
double power(double x, int n);
int main()
{	double a=3.0,c;
	int b=4;
	c = power(a,b);
	cout << a << "," << b << "," << c << endl;
	return 0;
}
